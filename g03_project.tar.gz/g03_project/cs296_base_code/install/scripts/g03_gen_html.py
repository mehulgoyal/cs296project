#!/usr/bin/python
import os
import re



def junk(str):								# gets a string as an argument
	line = str.splitlines()               # type(line) = list, type(str) = string
	line2 = ''.join(line)					# type(line2) = string 
	line3 = line2.split('{section}')		# type(line3) = list
	line4 = line3[1]						# type(line4) = string and it contains data from the section that we require
	line5 = line4.splitlines()
	line6 = ''.join(line5)
	line7 = line6.split('{subsection}')
	#print line7 
	return line7							# returns a list of "subsections" starting with section heading.
	
	
def mainhead(str):							# returns a tuple that consists of head of subsection and the remaining string
	str1 = str.partition('}')
	str2 = str1[0]
	str3 = str2.replace("{" , "")
	str4 = str1[2]
	str5 = str4[0:]
	#print str5
	return str3,str5    							# type is a string
	
def sub_parser(list):						# list is a string 
	#print list 
	tup = mainhead(list)
	#print tup[1]     
	head = tup[0]
	list0 = tup[1].replace(r"\(\approx",r"=")
	list01=list0.replace(r"\cite{klepkolen}",r"")
	list02=list01.replace(r"\cite{box2dman}",r"")
	list9 = list02.replace(r"\%\)",r"%")
	list91 = list9.replace(r"\)",r"")
#	print(list9)
	list8=list91.replace(r"\begin{center}\includegraphics[width=14cm, height=9cm]{doc/",r'<br><br><br><center><img src="')
	list7=list8.replace(r"}\end{center}", r'"></center><br><br><br>')
	list81=list8.replace(r"\begin{center}\includegraphics[width=14cm, height=11.5cm]{doc/",r'<br><br><br><center><img src="')
	list71=list81.replace(r"}\end{center}", r'"></center><br><br><br>')
	list82=list71.replace(r"\begin{center}\includegraphics[scale=0.5]{plots",r'<br><br><br><center><img src="./../plots/')
	list72=list82.replace(r"}\end{center}", r'"></center><br><br><br>')
	list83=list72.replace(r"\begin{center}\includegraphics{doc/",r'<br><br><br><center><img src="')
	list73=list83.replace(r"}\end{center}", r'"></center><br><br><br>')
	list6 = list73.replace(r"\(\Rightarrow\)", "implies")
	listed1 = list6.replace(r"\end","")
	list1 = listed1.replace(r"\\","<br>")
#	print list0
#	list9 = list0.replace("{","<b>")
#	list8 = list9.replace("}", "</b>")
#	list7 = list8.replace(r"\textbf","")
	
	#print tup[1]
	#print(list1) 											# debug point 1
	#list3 = list2.split('{subsection}')
	mylist = ['<div class="subsection" id="subparts"> <h4>',head,"</h4>"]
	str = ''.join(mylist)
	mylist3 = [str,list1]
	str2 = ''.join(mylist3)
	#print mylist3
	mylist2 = [str2, "</div>"]
	str3 = ''.join(mylist2)
	#print str3
	return str3
		
def parser(list):						# recieves a list of partitions
	tup1 = mainhead(list[0])		# before first subsection, pararaph after begin section
	head = tup1[0]       			# replaces { from the head of section	
	#print tup1[1]
	list2 = tup1[1]					# second element of tuple is the string after removal of section head
	mylist1 = ['<html>','<body> <div class="section" id="timings" > <h1>',head,"</h1>"]
	str9 = ''.join(mylist1)			#initial body of html
	#stra = str.join()
	#print str
	list3 = list[1:]			
	#print list3
	mylist2 = [str9,"<p>",list2.replace(r"\begin",""),"</p> <br>"]
	str2 = ''.join(mylist2)
	#print str2	
	return_list = []		
	return_list.append(str2)			# this is the list 
	#print list3
	for i in range(len(list3)):
		if i%2==0:
			return_list.append(sub_parser(list3[i]))#+'<img src="./../plots/g03_lab09_plot0'+str(int(i/2+1))+'.png">')			# subparser gets a string as an argumen
	return_list.append("</div></body></html>")
	#print return_list
	return return_list
	

filename="./doc/g03_project_report.tex"
	
	
if filename and os.path.isfile(filename):
    linestring = open(filename, 'r').read()
    modline1 = junk(linestring)					# modeline is the list of subsections
    #print modline1								
    modline2 = parser(modline1)	
    final = ''.join(modline2)					
    #print modline2
    #print ''.join(modline2)					# final string
    
text_file = open("./doc/g03_project_report.html", "w")
text_file.write(final)
text_file.close()
    
    #line = linestring.split('{section}')
    #line2 = line[1]
	#newlin1 = line2.splitlines()
	#newlin2 = ''.join(newlin1)
	#newlin3 = newlin2.split('{subsection}'
	
	
	
# re.serve
