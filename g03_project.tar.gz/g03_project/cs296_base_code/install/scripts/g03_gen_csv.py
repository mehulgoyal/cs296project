import subprocess
text_file = open("./data/lab09_g03_data.csv", "w")
for j in range(1,101):
	i=1
	for i in range(1,101):
		output=subprocess.Popen(['./mybins/cs296_base_prof',str(j)],stdout=subprocess.PIPE)
		b=output.communicate()[0].decode("utf-8")
		b=b.split()
		text_file.write(str(i)+","+b[2]+","+b[8]+","+b[15]+","+b[23]+","+b[31]+","+b[38]+"\n")
text_file.close()

