import matplotlib
import matplotlib.pyplot as plt
import csv
import numpy as np
import math

res=csv.reader(open('./data/lab09_g03_data.csv'), delimiter=',')

a=0
width=0.2
numitrvals=100

"""for col in res:
	if (int(col[0])<1):
		numitrvals+=1
	else:
		break"""


xarray= [0 for x in range(numitrvals)]
step1 = [0 for x in range(numitrvals)]
loop1 = [0 for x in range(numitrvals)]
vel1 = [0 for x in range(numitrvals)]
pos1 = [0 for x in range(numitrvals)]
col1 = [0 for x in range(numitrvals)]
step2 = [0 for x in range(numitrvals)]
loop2 = [0 for x in range(numitrvals)]
vel2 = [0 for x in range(numitrvals)]
pos2 = [0 for x in range(numitrvals)]
col2 = [0 for x in range(numitrvals)]
errorbars= [0 for x in range(numitrvals)]
sd2=[[] for x in range(numitrvals)]
hist=[0 for x in range(numitrvals)]

for col in res:
     step1[int(col[1])-1]+=float(col[2])
     loop1[int(col[1])-1]+=float(col[6])
     vel1[int(col[1])-1]+=float(col[4])
     pos1[int(col[1])-1]+=float(col[5])
     col1[int(col[1])-1]+=float(col[3])
     step2[int(col[0])-1]+=float(col[2])
     loop2[int(col[0])-1]+=float(col[6])
     vel2[int(col[0])-1]+=float(col[4])#pending "-1" for col[0] entries
     pos2[int(col[0])-1]+=float(col[5])
     col2[int(col[0])-1]+=float(col[3])
     sd2[int(col[1])-1].append(float(col[2]))
     if int(col[0]) == 17:
     	hist[int(col[1])-1]=float(col[2])
     
for x in range(numitrvals):
     step1[x]/=numitrvals
     loop1[x]/=numitrvals
     vel1[x]/=numitrvals
     pos1[x]/=numitrvals
     col1[x]/=numitrvals
     step2[x]/=numitrvals
     loop2[x]/=numitrvals
     vel2[x]/=numitrvals
     pos2[x]/=numitrvals
     col2[x]/=numitrvals
     xarray[x]=x+1
     erbars=0
     for y in sd2[x]:
          erbars+=(y-step1[x])**2
     errorbars[x]=math.sqrt(erbars/100)

     
     
plt.figure(0)
plt.plot(xarray,step1, color="blue", linewidth=1.1, linestyle="-", label="Step time")
plt.plot(xarray,loop1, color="red",  linewidth=1.1, linestyle="-", label="Loop time")
plt.legend(loc=7)
plt.xlabel("Iteration value")
plt.ylabel("Time in ms")
plt.title("Step time and loop time (averaged over reruns) vs iteration value")
plt.savefig('./plots/g03_project_plot01.png')
plt.show()

plt.figure(1)
plt.plot(xarray,step1, color="blue", linewidth=1.1, linestyle="-", label="Step time")
plt.plot(xarray,vel1, color="red",  linewidth=1.1, linestyle="-", label="Velocity update time")
plt.plot(xarray,pos1, color="green",  linewidth=1.1, linestyle="-", label="Position update time")
plt.plot(xarray,col1, color="purple",  linewidth=1.1, linestyle="-", label="Collision time")
plt.legend(loc=1)
plt.xlabel("Iteration value")
plt.ylabel("Time in ms")
plt.title("Step time, velocity update time, position update time \nand collision time (averaged over reruns) vs iteration value")
plt.savefig('./plots/g03_project_plot02.png')
plt.show()

plt.figure(2)
plt.plot(xarray,step2, color="blue", linewidth=1.1, linestyle="-", label="Step time")
plt.plot(xarray,loop2, color="red",  linewidth=1.1, linestyle="-", label="Loop time")
plt.legend(loc=7)
plt.xlabel("Rerun number")
plt.ylabel("Time in ms")
plt.title("Step time and loop time (averaged over iteration values) vs rerun number")
plt.savefig('./plots/g03_project_plot03.png')
plt.show()

plt.figure(3)
plt.plot(xarray,step2, color="blue", linewidth=1.1, linestyle="-", label="Step time")
plt.plot(xarray,vel2, color="red",  linewidth=1.1, linestyle="-", label="Velocity update time")
plt.plot(xarray,pos2, color="green",  linewidth=1.1, linestyle="-", label="Position update time")
plt.plot(xarray,col2, color="purple",  linewidth=1.1, linestyle="-", label="Collision time")
plt.legend(loc=7)
plt.xlabel("Rerun number")
plt.ylabel("Time in ms")
plt.title("Step time, velocity update time, position update time \nand collision time (averaged over iteration values) vs rerun number")
plt.savefig('./plots/g03_project_plot04.png')
plt.show()

plt.figure(4)
plt.errorbar(xarray,step1, yerr= errorbars, color="blue", linewidth=1.1, linestyle="-", label="Step time")
plt.legend(loc=7)
plt.xlabel("Iteration value")
plt.ylabel("Time in ms")
plt.title("Step time (average and deviation over reruns) vs iteration value")
plt.savefig('./plots/g03_project_plot05.png')
plt.show()


numcounts, cdfptsx = np.histogram(hist, bins=25)
cdfptsy = np.cumsum(numcounts)


plt.figure(5)
plt.hist(hist, bins=25, color="green", label="Step time frequency")
plt.plot(cdfptsx[1:], cdfptsy,color="blue",linewidth=1.1,linestyle="-",label="Cumulative step time frequency")
plt.xlabel("Step time in ms")
plt.ylabel("Frequency")
plt.legend(loc=7)
plt.title("Step time frequency histogram and \ncumulative frequency graph (over reruns) for iteration value 17")
plt.savefig('./plots/g03_project_plot06.png')
plt.show()

