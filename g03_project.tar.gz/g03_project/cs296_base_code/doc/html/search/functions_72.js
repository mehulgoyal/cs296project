var searchData=
[
  ['resize_5fcb',['resize_cb',['../classcs296_1_1callbacks__t.html#a54aa6b624b64d010ee90e9fbbaba6452',1,'cs296::callbacks_t']]],
  ['restart_5fcb',['restart_cb',['../classcs296_1_1callbacks__t.html#aa9407b70147973da3b267bd10af68368',1,'cs296::callbacks_t']]]
];
