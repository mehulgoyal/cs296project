var searchData=
[
  ['velocity_5fiterations',['velocity_iterations',['../structcs296_1_1settings__t.html#a59e5b6b0abd0fba1adb651062fc726b9',1,'cs296::settings_t']]],
  ['view_5fcenter',['view_center',['../structcs296_1_1settings__t.html#ad441969bd9f72a0e8cabcdbd2072b05d',1,'cs296::settings_t']]],
  ['view_5fzoom',['view_zoom',['../namespacecs296.html#acd94f8ca6c6ebfd23f6742211acfe446',1,'cs296']]]
];
