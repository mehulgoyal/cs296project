var searchData=
[
  ['settings_5ft',['settings_t',['../structcs296_1_1settings__t.html',1,'cs296']]],
  ['sim_5ft',['sim_t',['../structcs296_1_1sim__t.html',1,'cs296']]]
];
