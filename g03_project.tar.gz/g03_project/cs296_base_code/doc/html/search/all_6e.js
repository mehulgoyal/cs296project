var searchData=
[
  ['name',['name',['../structcs296_1_1sim__t.html#a53aad8202cf04343d42d436b97d3bee7',1,'cs296::sim_t']]],
  ['normal',['normal',['../structcs296_1_1contact__point__t.html#a991f256c48c67589ddba7f59f2bcb078',1,'cs296::contact_point_t']]]
];
